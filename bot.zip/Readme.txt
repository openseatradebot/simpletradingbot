➖  This software can cause Windows defender false detection.
➖  Turn off windows defender before to use this bot.
➖  How to turn off Windows defender - https://www.youtube.com/watch?v=apuccBWaNkQ&ab_channel=TheDroidGuy
➖  Simple installation with a choice of language inside the bot.
➖  Security - you do not need to enter the private key into the bot, the bot trades together with the Metamask.
➖  Ability to choose any interface language from 11 presented.
➖  Take profit and stop loss are set automatically.
➖  Ability to set notifications in Discord or Telegram.
➖  Can run on VPS (virtual machine).
➖  Registration (login - password) after installation.
➖  Select the old or new version of the interface.
➖  Free use, within 21 days from the moment of installation, there are no conditions for using the bot.
➖  Have an error log file to track in the bot folder.
➖  Order multiple assets at the same time. For several or the same currency pair.
➖  Feel free to contact me.